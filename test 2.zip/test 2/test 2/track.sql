savepoint p1;
Begin;
Delete from chinook_music.invoiceline where trackId=3177;
savepoint p2;
Delete from chinook_music.playlisttrack where TrackId=3177;
savepoint p3;
Delete from chinook_music.track where TrackId = 3177;
rollback to savepoint p3;
commit;