
package com.trios;
import jakarta.persistence.*;

@Entity
@Table(name="user")
public class user {
    @Id
    @Column(name = "userID",unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String userID;
    @Column(name="trackName")
    private String trackName;
    @Column(name="userName")
    private String userName;
    @Column(name="trackTitle")
    private String trackTitle;
    @Column(name="trackid")
    private int trackid;
    @Column(name="trackprice")
    private int trackprice;
  

    public String getuserID() {
        return userID;
    }

    public void setuserID(String userID) {
        userID = userID;
    }

    public String gettrackName() {
        return trackName;
    }

    public void settrackName(String trackName) {
        trackName = trackName;
    }

    public String gettrackTitle() {
        return trackTitle;
    }

    public void settrackTitle(String trackTitle) {
        trackTitle = trackTitle;
    }

    public int gettrackid() {
        return trackid;
    }

    public void settrackid(int trackid) {
        trackid = trackid;
    }

    public int trackprice() {
        return trackprice;
    }

    public void settrackprice(String trackprice) {
        trackprice = trackprice;
    }

 
